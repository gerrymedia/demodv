-- phpMyAdmin SQL Dump
-- version 3.3.10.4
-- http://www.phpmyadmin.net
--
-- Host: mysql.phpprince.com
-- Generation Time: Mar 14, 2014 at 05:56 AM
-- Server version: 5.1.56
-- PHP Version: 5.3.27

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dvtest01`
--

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `published` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `title`, `image`, `published`) VALUES
(1, 'Cat', 'img_cat.jpg', '1'),
(2, 'Dog', 'img_dog.jpg', '1'),
(5, 'Birds', 'img_birds.jpg', '1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `createdate`) VALUES
(1, 'travis', 'thardman@dailyvoice.com', 'da898a6b0481f9febf379ede22f5e3e8', '2014-03-12 00:00:00'),
(2, 'msquashic', 'msquashic@dailyvoice.com', 'c85ab5c9fa3327cc9cfb98865cc47d79', '2014-03-12 00:00:00'),
(3, 'gerry', 'gerrymedia@gmail.com', '0a16ad809916ef1f8cc423d144ba0dde', '2014-03-14 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE IF NOT EXISTS `votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  `vote` varchar(5) NOT NULL,
  `votedate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `user_id`, `image_id`, `vote`, `votedate`) VALUES
(1, 1, 1, 'up', '2014-03-12 21:37:00'),
(2, 1, 2, 'up', '2014-03-12 21:37:56'),
(3, 4, 1, 'up', '2014-03-12 21:51:31'),
(4, 7, 1, 'up', '2014-03-12 21:51:31'),
(5, 8, 1, 'up', '2014-03-13 13:23:45'),
(6, 9, 1, 'down', '2014-03-12 21:52:10'),
(7, 56, 2, 'up', '2014-03-12 23:15:47'),
(8, 50, 2, 'up', '2014-03-12 23:15:47'),
(9, 36, 2, 'down', '2014-03-12 23:16:12'),
(15, 1, 5, 'up', '2014-03-14 05:06:10');
